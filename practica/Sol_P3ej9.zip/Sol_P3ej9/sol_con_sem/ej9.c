#include "ej9.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

void barrier_init(struct barrier *b, int n){
    b->contador = 0;
    b->cantthreads = n;
    sem_init(&(b->semaforoentrada), 0, 0);
    sem_init(&(b->semaforosalida), 0, 1);
    pthread_mutex_init(&(b->lock), NULL);
}


void barrier_wait(struct barrier *b){
    pthread_mutex_lock(&(b->lock));
    b->contador++;
    if(b->contador == b->cantthreads){
        sem_wait(&(b->semaforosalida));
        sem_post(&(b->semaforoentrada));
    }
    pthread_mutex_unlock(&(b->lock));

    sem_wait(&(b->semaforoentrada));
    sem_post(&(b->semaforoentrada));

    pthread_mutex_lock(&(b->lock));
    b->contador--;
    if(b->contador == 0){
        sem_wait(&(b->semaforoentrada));
        sem_post(&(b->semaforosalida));
    }
    pthread_mutex_unlock(&(b->lock));

    sem_wait(&(b->semaforosalida));
    sem_post(&(b->semaforosalida));
}
