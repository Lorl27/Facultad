#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include "ej9.h"
#define N 30
#define W 5
#define ITERS 10

struct barrier b;
float arr1[N], arr2[N];

void calor(float *arr, int lo, int hi, float *arr2) {
    int i;
    for (i = lo; i < hi; i++) {
        int m = arr[i];
        int l = i > 0 ? arr[i-1] : m;
        int r = i < N-1 ? arr[i+1] : m;
        arr2[i] = m + (l - m)/1000.0 + (r - m)/1000.0;
}
}

int min(int a, int b){
    if(a < b){
        return a;
    }else{
        return b;
    }
}

/* Dado un array de [n], devuelve el punto de corte [i] de los [m] totales. */
static inline int cut(int n, int i, int m) {
    return i * (n/m) + min(i, n %m);
}

void * thr(void *arg) {
    int id = arg - (void*)0; /* 0 <= id < W */
    int lo = cut(N, id, W), hi = cut(N, id+1, W);
    int i;
    for (int i = 0; i < ITERS; i++) {
        barrier_wait(&b);
        calor(arr1, lo, hi, arr2);
        barrier_wait(&b);
        calor(arr2, lo, hi, arr1);
    }
}

int main(){
    pthread_t LOSTHREADS[W];
    barrier_init(&b, W);

    for (int i = 0; i < W; i++)
        pthread_create(&LOSTHREADS[i], NULL, thr, i + (void*)0);
    pthread_join(LOSTHREADS[0], NULL);

}