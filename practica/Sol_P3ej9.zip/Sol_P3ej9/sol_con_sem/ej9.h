#define EJ9_H

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

struct barrier{
    int contador;
    int cantthreads;
    sem_t semaforoentrada;
    sem_t semaforosalida;
    pthread_mutex_t lock;
};

void barrier_init(struct barrier *b, int n);
void barrier_wait(struct barrier *b);
