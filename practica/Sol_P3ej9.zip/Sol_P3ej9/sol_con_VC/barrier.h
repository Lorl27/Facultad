#include <pthread.h>

struct barrier{
  int maxThreads;
  int threadCount;
  pthread_mutex_t gate;
  pthread_cond_t cv;
};

void barrier_init(struct barrier *b, int n);

void barrier_wait(struct barrier *b);