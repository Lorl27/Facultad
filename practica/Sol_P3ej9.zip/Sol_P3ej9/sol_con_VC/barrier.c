#include "barrier.h"

void barrier_init(struct barrier *b, int n){
  b->maxThreads = n;
  b->threadCount = 0;
  pthread_mutex_init(&b->gate, NULL);
  pthread_cond_init(&b->cv, NULL);
}

void barrier_wait(struct barrier *b){
  //lock
  /**
   * cantidad de hilos esperando ++
   * if n == cantidad de hilos esperando
   * then broadcast cond && cantidad de hilos esperando = 0
   * else wait cond, lock && unlock
  */

  pthread_mutex_lock(&b->gate);
  b->threadCount++;
  if (b->threadCount == b->maxThreads)
  {
    pthread_cond_broadcast(&b->cv);
    b->threadCount = 0;
  } else {
    pthread_cond_wait(&b->cv, &b->gate);
  }
  pthread_mutex_unlock(&b->gate);
}
