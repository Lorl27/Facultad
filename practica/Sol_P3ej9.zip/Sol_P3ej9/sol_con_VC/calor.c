#include "barrier.h"
#include <stdio.h>
#include <time.h>

#define N 10
#define W 2
#define ITERS 10

// Asumimos se inicializa la barrera de la siguiente forma antes de crear los hilos:
// barrier_init(&b, W);
struct barrier b;

float arr1[N], arr2[N];
void calor(float *arr, int lo, int hi, float *arr2) {
  int i;
  for (i = lo; i < hi; i++) {
    int m = arr[i];
    int l = i > 0 ? arr[i-1] : m;
    int r = i < N-1 ? arr[i+1] : m;
    arr2[i] = m + (l - m)/1000.0 + (r - m)/1000.0;
  }
}

int min(int m, int n) { return n > m? m:n;}

/* Dado un array de [n], devuelve el punto de corte [i] de los [m] totales. */
static inline int cut(int n, int i, int m) {
  return i * (n/m) + min(i, n %m);
}

void * thr(void *arg) {
  int id = arg - (void*)0; /* 0 <= id < W */
  int lo = cut(N, id, W), hi = cut(N, id+1, W);
  int i;

  for (i = 0; i < ITERS; i++) {
    calor(arr1, lo, hi, arr2);
    barrier_wait(&b);
    calor(arr2, lo, hi, arr1);
    barrier_wait(&b);
  }

  return NULL;
}


int main(){
  pthread_t t[W];
  barrier_init(&b, W);

  for (int i = 0; i < N; i++) {
    arr1[i] = (i+1)*10;
  }

  for(int i = 0; i < W; i++){
    pthread_create(&t[i], NULL, thr, i +(void*)0);
  }

  for(int i = 0; i < W; i++){
    pthread_join(t[i], NULL);
  }
  return 0;
}
