#ifndef NODE_ID_H
#define NODE_ID_H

void obtener_id_unico(char *nombre);

#endif