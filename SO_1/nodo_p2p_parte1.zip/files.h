#ifndef FILES_H
#define FILES_H

void init_file_list();
void listar_archivos();

#endif