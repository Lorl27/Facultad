#ifndef CLI_H
#define CLI_H

void *cli_loop(void *arg);

#endif