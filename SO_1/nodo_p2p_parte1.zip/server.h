#ifndef SERVER_H
#define SERVER_H

void start_tcp_server(int port);

#endif