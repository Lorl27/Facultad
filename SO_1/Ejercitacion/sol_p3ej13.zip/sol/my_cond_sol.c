#include "my_cond_sol.h"

#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void my_cond_init(my_cond_t *cond) {
    // Inicializa el semáforo en 0, cuando se la haga wait quedará lockeado.
  sem_init(&cond->condition, 0, 0);
  sem_init(&cond->leaving, 0, 0);
  cond->waiting = 0;
  pthread_mutex_init(&cond->lock, NULL);
}

void my_cond_wait(my_cond_t *cond, pthread_mutex_t *mutex) {
     pthread_mutex_lock(&cond->lock);
    // suelta el mutex.
    pthread_mutex_unlock(mutex);
    cond->waiting++;
    pthread_mutex_unlock(&cond->lock);
    // Baja el semáforo y espera un signal o un broadcast.  
    sem_wait(&cond->condition);
    //recibio una señal
    sem_post(&cond->leaving);
    // pide el mutex.
    pthread_mutex_lock(mutex);
}

void cv_signal(my_cond_t *cond) {
  pthread_mutex_lock(&cond->lock);
  
  if (cond->waiting > 0) {
    cond->waiting--;
    sem_post(&cond->condition);
    sem_wait(&cond->leaving);
  }
  pthread_mutex_unlock(&cond->lock);
}

void my_cond_broadcast(my_cond_t *cond) {
  pthread_mutex_lock(&cond->lock);

  int n = cond->waiting;

  for (int i = 0; i < n; i++)
    sem_post(&cond->condition);

  for (int i = 0; i < n; i++)
    sem_wait(&cond->leaving);

  cond->waiting = 0;

  pthread_mutex_unlock(&cond->lock);
}

void my_cond_destroy(my_cond_t *cond) {
  
    sem_destroy(&(cond->leaving));
    sem_destroy(&(cond->condition));
    pthread_mutex_destroy(&(cond->lock));
}







