#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

// Los recursos disponibles
sem_t tobacco;
sem_t paper;
sem_t matches;
sem_t again;

// Ver que recursos hay disponibles
int tobacco_available = 0;
int paper_available = 0;
int matches_available = 0;

// Mutex que protege las variables anteriores
pthread_mutex_t bool_mutex = PTHREAD_MUTEX_INITIALIZER;

// Los fumadores estan atentos a estos semaforos
sem_t tobacco_smoker;
sem_t paper_smoker;
sem_t matches_smoker;


/*  Los managers interceptan los semaforos que el agente postea
y luego se encargan de levantar a los fumadores correctos.
  De esta manera, los fumadores ya no waitean a los mismos
semaforos que el agente postea, si no a unos nuevos que son 
posteados por los managers */

void* tobacco_manager(void* arg) {

  while(1) {
  
    sem_wait(&tobacco);

    // Toma el lock que proteje a todos los bools simultaneamente
    pthread_mutex_lock(&bool_mutex);

    /* Si alguno de los managers se ejecuto antes y ya marco que
    su respectivo recurso esta disponible, levantamos al smoker
    asociado */
    if (paper_available) { 

      paper_available = 0;
      sem_post(&matches_smoker); 
    }

    else if (matches_available) {

      matches_available = 0;
      sem_post(&paper_smoker);
    }

    /* Si fue el primero en despertarse, solo marca que su recurso
    ya esta disponible */
    else tobacco_available = 1;

    pthread_mutex_unlock(&bool_mutex);
  }
}

void* paper_manager(void* arg) {

  while (1) {
      
    sem_wait(&paper);

    pthread_mutex_lock(&bool_mutex);

    /* Si alguno de los managers se ejecuto antes y ya marco que
    su respectivo recurso esta disponible, levantamos al smoker
    asociado */

    if (tobacco_available) { 

      tobacco_available = 0;
      sem_post(&matches_smoker); 
    }

    else if (matches_available) {

      matches_available = 0;
      sem_post(&tobacco_smoker);
    }

    /* Si fue el primero en despertarse, solo marca que su recurso
    ya esta disponible */

    else paper_available = 1;

    pthread_mutex_unlock(&bool_mutex);
  }
}

void* matches_manager(void* arg) {

  while (1) {
      
    sem_wait(&matches);

    pthread_mutex_lock(&bool_mutex);

    /* Si alguno de los managers se ejecuto antes y ya marco que
    su respectivo recurso esta disponible, levantamos al smoker
    asociado */

    if (paper_available) { 

      paper_available = 0;
      sem_post(&tobacco_smoker); 
    }

    else if (tobacco_available) {

      tobacco_available = 0;
      sem_post(&paper_smoker);
    }

    /* Si fue el primero en despertarse, solo marca que su recurso
    ya esta disponible */

    else matches_available = 1;

    pthread_mutex_unlock(&bool_mutex);
  }
}




void agent() {

  while (1) {

    sem_wait(&again);
    int option = random() % 3; 

    printf("Option: %i\n", option);

    // Reponemos dos de las tres opciones posibles
    if (option != 0) sem_post(&matches);
    if (option != 1) sem_post(&paper);
    if (option != 2) sem_post(&tobacco);
  }
}


void smoke(int smoker) {

  printf("Fumador %d: Puf! Puf! Puf!\n", smoker);
  sleep(1);
}


void* smoker1(void* arg) { // Tiene los fosforos

  while (1) {
      /* Solo tiene que waitear a su semaforo asociado */
      sem_wait(&matches_smoker);
      smoke(1); 

      /* Y senialar que ya fumo */
      sem_post(&again); 
  }
}


void* smoker2(void* arg) { // Tiene el papel

  while (1) {

      /* Solo tiene que waitear a su semaforo asociado */
      sem_wait(&paper_smoker);
      smoke(2);

      /* Y senialar que ya fumo */
      sem_post(&again); 
  }
}

void* smoker3(void* arg) { // Tiene el tabaco

  while (1) {
      
    /* Solo tiene que waitear a su semaforo asociado */
    sem_wait(&tobacco_smoker);
    smoke(3);

    /* Y senialar que ya fumo */
    sem_post(&again);
  }
}


int main() {
  
  pthread_t s1, s2, s3;  
  pthread_t m1, m2, m3;

  sem_init(&tobacco, 0, 0);
  sem_init(&paper, 0, 0);
  sem_init(&matches, 0, 0);
  sem_init(&again, 0, 1);

  sem_init(&tobacco_smoker, 0, 0);
  sem_init(&paper_smoker, 0, 0);
  sem_init(&matches_smoker, 0, 0);


  pthread_create(&s1, NULL, smoker1, NULL);
  pthread_create(&s2, NULL, smoker2, NULL);
  pthread_create(&s3, NULL, smoker3, NULL);

  pthread_create(&m1, NULL, matches_manager, NULL);
  pthread_create(&m2, NULL, paper_manager, NULL);
  pthread_create(&m3, NULL, tobacco_manager, NULL);

  agent();

}


