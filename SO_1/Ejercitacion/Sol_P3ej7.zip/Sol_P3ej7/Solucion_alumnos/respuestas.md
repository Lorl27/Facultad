### a) Cómo puede ocurrir un deadlock en ésta implementación?

Supongamos que, en una iteración dada del ciclo `while` del agente vale `random() % 3 == 2`, luego se produce la asignación `caso = 2`. El agente entonces ejecutará las instrucciones

```C
sem_post(&matches);
sem_post(&paper);
```

y luego

```C
sem_wait(&otra_vez)
```

donde el `thread` que ejecuta al agente se quedará bloqueado a la espera de un post sobre el semáforo `otra_vez`.

Ahora consideremos el siguiente orden de ejecución. Inmediatamente despues de realizarse ambos post, el `thread` que ejecuta a `fumador2` despierta y ejecuta la línea

```C
sem_wait(&matches);
```

Como el contador de `matches` estará en 1, podrá decrementar el contador a 0 y no se bloqueara. Ahora, supongamos que continúa con su ejecución y se realiza el llamado

```C
sem_wait(&tobacco);
```

Ahora, `fumador2` estará bloqueado, pues el semáforo `tobacco` estara en 0, quedando el `thread` a la espera de que este incremente para poder llevarlo a 0 nuevamente.

Supongamos ahora que continúa la ejecución del `thread` que corre a `fumador1()` (si continuará con `fumador3()` sería lo mismo). Tras entrar al ciclo `while`, ejecutará la linea

```C
sem_wait(&tobacco);
```
donde se quedará bloqueado, pues el semáforo `tobacco` está inicializado en 0.

Por otro lado, si ahora continúa el `thread` que corre a `fumador3()`, al ejecutarse las líneas

```C
sem_wait(&paper);
sem_wait(&matches);
```

no se quedará bloqueado en el primer `sem_wait()`, pues `agente()` incremento el semáforo `paper` a 1, pero se quedará bloqueado al intentar ejecutar `sem_wait(&matches)`, pues el `thread` que corre a `fumador2()` ya decremento el contador del semáforo `matches` a 0.

Entonces, en esta secuencia de ejecución los 4 `thread`s involucrados están bloqueados en un llamado a `sem_wait()` y ningún un otro `thread` puede llamar a `sem_post()` para desbloquearlos, por lo que se produjo un deadlock.

### b) Pueden ordenarse los recursos para evitar el problema?

Considerando que el orden en el que el agente realiza los posts es fijo, dado cada par de recursos
existe una unica manera en la que los otorga. Sean M, P, y T los matches, paper, y tobacco respectivamente.
Entonces, el agente libera los recursos en una de las siguientes tres secuencias: MP, MT, o PT. Incluso si las instrucciones se reordenaran a la hora de compilación, podríamos utilizar un argumento similiar, sobre las secuencias posibles, en el programa compilado.

Ahora, notemos que podemos modificar como solicitarán los recursos los fumadores. Esto es, en que orden
realizaran los wait en su código. Tenemos tres fumadores:

- El fumador 1, que tiene M, y necesita P y T.
- El fumador 2, que tiene P, y necesita M y T.
- El fumador 3, que tiene T, y necesita M y P.

Entonces, arbitrariamente podemos fijar el orden en el que el fumador 1 pide los recursos como primero P
y luego T. Luego, notemos que si el agente libera los recursos en la secuencia PT, querremos que el fumador 1 no compita ni por P ni por T con los demas fumadores, pues si alguno de ellos tomara el recurso, se producirá un deadlock. Entonces, el haber elegido que el fumador 1 pida primero P y luego T nos impone la restricción de que el fumador 2 pida primero M y T, y que el fumador 3 pida primero M y luego P. De esta manera, ambos se bloquearan en el pedido de M y el fumador 1 podrá obtener ambos recursos.

Es decir, elegir PT para fumador 1 nos fuerza a elegir MT para el 2 y MP para el 3. Ahora, si el agente en vez de otorgar PT libera MP, tenemos que tanto el fumador 2 como el 3 competiran por M, pero si el fumador 2 lo obtiene se producirá un deadlock, ya que se bloqueará a la espera de T que nunca sucederá, y el agente no podrá volver a repartir los recursos, pues nadie señalara `again`. Es decir, no podemos elegir PT como orden para el fumador 1.

Por el contrario entonces, elijamos TP para el fumador 1. Análogamente al caso anterior, esto nos provoca que si el agente libera PT, el fumador 2 debería elegir el orden MT y el fumador 3 deberá elegir MP, para evitar competir por el T. Pero entonces de nuevo, no hay orden que pueda garantizar que evita el deadlock cuando el agente libera MP. 

Finalmente, como no hay orden posible para el fumador 1 que garantice que no se producirá un deadlock, en general no hay una solución para el problema únicamente ordenando el pedido de recursos.


### c) Explicación de la implementación (sin modificar agente)

En la version sin modificar al agente utilizaremos tres `threads` que posicionarán como intermediarios entre el agente y los fumadores. Estos seran los `managers`, uno por cada recurso

```C
void* tobacco_manager(void* arg);
void* paper_manager(void* arg);
void* matches_manager(void* arg);
```

Adicionalmente, para la implementación de esta solución necesitaremos tres variables booleanas y un `mutex` que las proteje a todas, definidos como

```C
int tobacco_available = 0;
int paper_available = 0;
int matches_available = 0;
```
```C
pthread_mutex_t bool_mutex = PTHREAD_MUTEX_INITIALIZER;
```

y tres nuevos semáforos,

```C
sem_t tobacco_smoker;
sem_t paper_smoker;
sem_t matches_smoker;
```

que los managers utilizarán para despertar a los fumadores.

La idea de esta solucion es que, en vez de que los fumadores esperen a los semáforos que el agente levanta, sean los managers quienes lo hacen. Los managers ejecutaran un ciclo `while` infinito donde la primer linea de cada uno es un `sem_wait(&<recurso>)` a sus respectivos recursos.

De esta manera, cuando el agente otorgue un ingrediente, solo el manager asociado a ese recurso se despertará. Luego, pedirá el lock del mutex `bool_mutex` (por el cual eventualmente competirá con los demás managers).

Si obtiene el mutex, entonces pueden suceder dos cosas:
- Si es el primer manager en haberse despertado y obtenido el mutex, entonces solo marca que su recurso está disponible, setteando el booleano asociado en true.
- Si otro manager ya despertó y obtuvo el lock anteriormente, entonces habrá setteado a una de las variables booleanas en true. En ese caso, el manager seguirá por la rama de alguno de los dos primeros `if`, dependiendo de cual fue el recurso que ya sabe que está disponible.
En cada caso, si cae en uno de esos dos primeros `if`, entonces el manager ya sabe exactamente cuales fueron los 2 recursos que el agente libero, por lo que puede levantar al smoker que los necesita, no sin antes marcar que se ha consumido el recurso.


Es decir, tras los dos post realizados por el agente, los managers podrán determinar cual es el fumador a despertar.

Solo resta entonces que los fumadores waiteen a un semáforo que los identifica, llamen a la funcion `smoke()`, y señalen al agente que vuelva a repartir los recursos, que es exactamente lo que realizan en la siguiente porcion de codigo

```C
    /* Solo tiene que wait
    ear a su semáforo asociado */
    sem_wait(&<su_recurso>_smoker);
    smoke(1); 

    /* Y señalar que ya fumo */
    sem_post(&again); 
```



### d) Soluciones alternativas

Si pudiésemos hacer modificaciones en el agente, podemos hacer tres nuevos semáforos:
- Uno indica que el agente esta  dando F y P.
- El otro indica que el agente esta dando P y T.
- El último indica que el agente esta dando F y T.

Al decidir sobre que recursos hará el restock, modificaría el semáforo adecuado y los fumadores estarían a la espera de las modificaciones de dichos semáforos. Ésta solución es trivial, y hace que los recursos otorgados por el agente, pierdan relevancia.


### e) Como se relaciona este ejercicio al servidor de turnos de la práctica anterior?

Se relacionan en que el problema de los fumadores podria haberse modelado, alternativamente, con un codigo similar al del servidor de turnos. En ese caso, el agente podria representarse como el servidor, y los fumadores podrian representarse con clientes del servidor.

Entonces, los `sem_wait()` de los fumadores podrian modelarse como pedidos al servidor y los `sem_post()` del agente podrian modelarse como mensajes del servidor hacia los clientes. El problema se reduciría entonces a gestionar el envío y recepción de mensajes correctamente en vez de sincronizar hilos.
