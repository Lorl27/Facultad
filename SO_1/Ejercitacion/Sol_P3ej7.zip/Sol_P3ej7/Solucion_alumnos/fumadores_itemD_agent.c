#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

sem_t tobacco;
sem_t paper;
sem_t matches;
sem_t again;

sem_t paper_tobacco;
sem_t paper_matches;
sem_t tobacco_matches;


void agent() {

  while (1) {

    sem_wait(&again);
    int option = random() % 3; // Elegimos la opcion que vamos a reponer

    printf("Option: %i\n", option);
    // Reponemos dos de las tres opciones posibles
    if (option != 0) sem_post(&matches);
    if (option != 1) sem_post(&paper);
    if (option != 2) sem_post(&tobacco);

    if (option == 0) sem_post(&paper_tobacco);
    if (option == 1) sem_post(&tobacco_matches);
    if (option == 2) sem_post(&paper_matches);

    
  }
}


void smoke(int smoker) {

  printf("Fumador %d: Puf! Puf! Puf!\n", smoker);
  sleep(1);
}

/**
 * En esta solucion, como el agente avisa cuales son los recursos que esta
 * reponiendo, los recursos en si dejan de tener utilidad para el ejercicio.
 * Es decir, no hace falta que los fumadores tomen los recursos, pero lo dejamos
 * para mantener la idea de que los fumadores realmente consumen los recursos.
*/


void* smoker1(void* arg) { // Tiene los fosforos

  while (1) {
      
    sem_wait(&paper_tobacco);
    sem_wait(&tobacco);
    sem_wait(&paper);
    smoke(1);
    sem_post(&again);
  }
}


void* smoker2(void* arg) { // Tiene el papel

  while (1) {
      
    sem_wait(&tobacco_matches);
    sem_wait(&matches);
    sem_wait(&tobacco);
    smoke(2);
    sem_post(&again);
  }
}

void* smoker3(void* arg) { // Tiene el tabaco

  while (1) {
    
    sem_wait(&paper_matches);
    sem_wait(&paper);
    sem_wait(&matches);
    smoke(3);
    sem_post(&again);
  }
}


int main() {
  
  pthread_t s1, s2, s3;
  
  sem_init(&tobacco, 0, 0);
  sem_init(&paper, 0, 0);
  sem_init(&matches, 0, 0);
  sem_init(&again, 0, 1);

  sem_init(&tobacco_matches, 0, 0);
  sem_init(&paper_matches, 0, 0);
  sem_init(&paper_tobacco, 0, 0);

  pthread_create(&s1, NULL, smoker1, NULL);
  pthread_create(&s2, NULL, smoker2, NULL);
  pthread_create(&s3, NULL, smoker3, NULL);

  agent();

}


