void* manejar_cliente(void* arg) {
    int cliente_id = *(int*)arg;
    
    log_f(__FILE__, __LINE__, "Nuevo cliente conectado: %d", cliente_id);
    
    char buffer[1024];
    int bytes = recv(socket_cliente, buffer, sizeof(buffer), 0);
    
    if (bytes <= 0) {
        log_f(__FILE__, __LINE__, "Error al recibir datos del cliente %d: %s", 
              cliente_id, strerror(errno));
        return NULL;
    }
    
    log_f(__FILE__, __LINE__, "Recibidos %d bytes del cliente %d", 
          bytes, cliente_id);
    
    // Procesar datos...
    usleep(100000);  // Simula trabajo
    
    log_f(__FILE__, __LINE__, "Cliente %d procesado exitosamente", cliente_id);
    return NULL;
}