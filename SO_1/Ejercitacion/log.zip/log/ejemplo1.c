#include "log.h"  // donde esté declarada log_f

int main() {
    log_f(__FILE__, __LINE__, "Iniciando aplicación");
    // Salida: Mon Jun 22 15:30:45 2026 - Th:0 - main.c:5 - Iniciando aplicación
    
    int valor = 42;
    log_f(__FILE__, __LINE__, "El valor es %d", valor);
    // Salida: ... - main.c:9 - El valor es 42
    
    return 0;
}