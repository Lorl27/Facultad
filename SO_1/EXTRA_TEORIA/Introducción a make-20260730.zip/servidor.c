/* servidor.c - Componente C del proyecto.
 *
 * Servidor TCP minimo: acepta una conexion, manda un saludo de
 * bienvenida y reenvia (echo) en mayusculas todo lo que reciba.
 *
 * Se comunica con el componente Erlang UNICAMENTE por sockets.
 * No ejecuta codigo Erlang ni es ejecutado por el. Son dos mundos
 * independientes que solo comparten un protocolo de texto sobre TCP.
 *
 * Uso:  ./servidor_c [puerto]   (puerto por defecto: 4000)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "util.h"

#define PUERTO_DEFECTO 4000
#define BUF 256

int main(int argc, char *argv[])
{
    int puerto = (argc > 1) ? atoi(argv[1]) : PUERTO_DEFECTO;
    if (!puerto_valido(puerto)) {
        fprintf(stderr, "Puerto invalido: %d\n", puerto);
        return 1;
    }

    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) { perror("socket"); return 1; }

    int opt = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in dir;
    memset(&dir, 0, sizeof(dir));
    dir.sin_family = AF_INET;
    dir.sin_addr.s_addr = INADDR_ANY;
    dir.sin_port = htons((unsigned short)puerto);

    if (bind(s, (struct sockaddr *)&dir, sizeof(dir)) < 0) {
        perror("bind"); return 1;
    }
    if (listen(s, 1) < 0) { perror("listen"); return 1; }

    printf("Servidor C escuchando en el puerto %d...\n", puerto);

    int c = accept(s, NULL, NULL);
    if (c < 0) { perror("accept"); return 1; }

    char saludo[BUF];
    armar_bienvenida(saludo, sizeof(saludo));
    write(c, saludo, strlen(saludo));

    char buf[BUF];
    ssize_t leidos;
    while ((leidos = read(c, buf, sizeof(buf) - 1)) > 0) {
        for (ssize_t i = 0; i < leidos; i++)
            buf[i] = (char)toupper((unsigned char)buf[i]);
        write(c, buf, (size_t)leidos);
    }

    close(c);
    close(s);
    return 0;
}
