%% cliente.erl - Componente Erlang del proyecto.
%%
%% Cliente TCP que se conecta al servidor C, le manda un par de
%% mensajes y muestra las respuestas. La comunicacion es 100% por
%% sockets: Erlang y C no comparten codigo, solo el protocolo de texto.
%%
%% Uso desde el shell de Erlang:
%%     cliente:start().              %% usa localhost y puerto por defecto
%%     cliente:start("127.0.0.1", 4000).

-module(cliente).
-export([start/0, start/2]).

start() ->
    start("127.0.0.1", protocolo:puerto_defecto()).

start(Host, Puerto) ->
    Opts = [binary, {packet, 0}, {active, false}],
    case gen_tcp:connect(Host, Puerto, Opts) of
        {ok, Sock} ->
            %% Leer el saludo de bienvenida del servidor C.
            {ok, Bienvenida} = gen_tcp:recv(Sock, 0),
            io:format("Servidor dice: ~s", [Bienvenida]),

            enviar(Sock, "hola desde erlang"),
            enviar(Sock, "make es genial"),

            gen_tcp:close(Sock),
            ok;
        {error, Motivo} ->
            io:format("No se pudo conectar: ~p~n", [Motivo]),
            {error, Motivo}
    end.

enviar(Sock, Texto) ->
    gen_tcp:send(Sock, protocolo:formatear(Texto)),
    {ok, Resp} = gen_tcp:recv(Sock, 0),
    io:format("Envie ~p -> recibi ~s~n", [Texto, Resp]).
