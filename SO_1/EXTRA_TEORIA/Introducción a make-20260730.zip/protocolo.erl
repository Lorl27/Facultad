%% protocolo.erl - Modulo de apoyo del componente Erlang.
%%
%% Define el formato de los mensajes que viajan por el socket hacia
%% el servidor C. Se mantiene separado de cliente.erl para que el
%% Makefile compile dos modulos .erl -> .beam de forma independiente.

-module(protocolo).
-export([puerto_defecto/0, formatear/1]).

%% Puerto donde escucha el servidor C.
puerto_defecto() -> 4000.

%% Prepara un texto para enviarlo por el socket (agrega salto de linea).
formatear(Texto) ->
    Texto ++ "\n".
