#include <stdio.h>
#include "util.h"

/* Validacion simple del numero de puerto. */
int puerto_valido(int puerto)
{
    return (puerto >= 1024 && puerto <= 65535);
}

/* Arma el mensaje de bienvenida que el servidor enviara por el socket. */
void armar_bienvenida(char *dest, int n)
{
    snprintf(dest, n, "Bienvenido al servidor C\n");
}
