#ifndef UTIL_H
#define UTIL_H

/* Funciones auxiliares del servidor C.
 * Se mantienen separadas en util.c para mostrar la compilacion
 * incremental: si solo cambia util.c, make recompila solo util.o. */

/* Devuelve 1 si el puerto es valido (1024-65535), 0 en caso contrario. */
int puerto_valido(int puerto);

/* Escribe en 'dest' un mensaje de bienvenida para el cliente.
 * 'dest' debe tener al menos 'n' bytes. */
void armar_bienvenida(char *dest, int n);

#endif /* UTIL_H */
