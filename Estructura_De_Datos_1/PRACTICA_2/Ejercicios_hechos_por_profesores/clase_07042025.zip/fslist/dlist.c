#include <stdlib.h>
#include "dlist.h"

DList* dlist_crear() {
    DList* nueva_lista = malloc(sizeof(DList));
    nueva_lista->primero = NULL;
    nueva_lista->ultimo = NULL;    
    return nueva_lista;
}

DNodo* crear_nodo (int dato) {
    DNodo* nuevo_nodo = malloc(sizeof(DNodo));
    nuevo_nodo->dato = dato;
    nuevo_nodo->sig = NULL;
    nuevo_nodo->ant = NULL;
    return nuevo_nodo;
}

void dlist_agregar_inicio (DList* lista, int dato) {
    DNodo* nuevo_nodo = crear_nodo(dato);
    nuevo_nodo->sig = lista->primero;
    if(lista->primero != NULL)
        lista->primero->ant = nuevo_nodo;
    else{
        lista->ultimo = nuevo_nodo;
    }
    lista->primero = nuevo_nodo;
}

void dlist_agregar_final (DList* lista, int dato) {
    DNodo* nuevo_nodo = crear_nodo(dato);
    nuevo_nodo->ant = lista->ultimo;
    if (lista->ultimo != NULL)
        lista->ultimo->sig = nuevo_nodo;
    else{ 
        lista->primero = nuevo_nodo;
    }
    lista->ultimo = nuevo_nodo;
}

void dlist_recorrer_adelante(DNodo* nodo, FuncionVisitante visit)
{
    for(DNodo* temp = nodo; temp != NULL; temp = temp->sig)
        visit(temp->dato);
}

void dlist_recorrer_atras(DNodo* nodo, FuncionVisitante visit)
{
    for(DNodo* temp = nodo; temp != NULL; temp = temp->ant)
        visit(temp->dato);
}

void dlist_recorrer(DList* lista, FuncionVisitante visit, DListOrdenDeRecorrido orden) {
    if(orden == DLIST_RECORRIDO_HACIA_ADELANTE) 
        dlist_recorrer_adelante(lista->primero, visit);
    else dlist_recorrer_atras(lista->ultimo, visit);
}

void dlist_recorrer_R_aux(DNodo* node, FuncionVisitante visit, DListOrdenDeRecorrido orden)
{
    if(node != NULL){
        visit(node->dato);
        if(orden == DLIST_RECORRIDO_HACIA_ADELANTE) dlist_recorrer_R_aux(node->sig, visit, orden);
        else dlist_recorrer_R_aux(node->ant, visit, orden);
    }
}


void dlist_recorrer_R(DList* lista, FuncionVisitante visit, DListOrdenDeRecorrido orden) {
    DNodo* primer_nodo = orden == DLIST_RECORRIDO_HACIA_ADELANTE ? lista->primero : lista->ultimo; 
    dlist_recorrer_R_aux(primer_nodo, visit, orden);
}
