#ifndef F_SLIST_H
#define F_SLIST_H

typedef void (*FuncionVisitante) (int dato);

typedef struct _SNodo {
    int dato;
    struct _SNodo *sig;
} SNodo;

typedef struct SList {
    SNodo *primero;
    SNodo *ultimo;
} SList;

SList* slist_crear ();

void slist_agregar_inicio (SList* lista, int dato);

void slist_agregar_final (SList* lista, int dato);

void slist_recorrer_R_feo (SList* lista, FuncionVisitante visit);

void slist_recorrer_R_ok (SList* lista, FuncionVisitante visit);

#endif