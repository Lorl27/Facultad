#include <stdlib.h>
#include <stdio.h>
#include "dlist.h"

void imprimir(int dato) {
    printf("%d ", dato);
}

int main () {
    DList* lista = dlist_crear();

    dlist_agregar_final(lista, 1);
    dlist_agregar_final(lista, 2);
    dlist_agregar_final(lista, 3);
    dlist_agregar_inicio(lista,4);
    dlist_agregar_inicio(lista,5);

    dlist_recorrer(lista, imprimir, DLIST_RECORRIDO_HACIA_ADELANTE);
    putchar('\n');
    dlist_recorrer(lista, imprimir, DLIST_RECORRIDO_HACIA_ATRAS);

    return 0;
}