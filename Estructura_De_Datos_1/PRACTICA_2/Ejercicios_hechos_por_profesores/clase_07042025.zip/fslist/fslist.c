#include <stdlib.h>
#include "fslist.h"

SList* slist_crear() {
    SList* nueva_lista = malloc(sizeof(SList));
    nueva_lista->primero = NULL;
    nueva_lista->ultimo = NULL;    
    return nueva_lista;
}

SNodo* crear_nodo (int dato) {
    SNodo* nuevo_nodo = malloc(sizeof(SNodo));
    nuevo_nodo->dato = dato;
    nuevo_nodo->sig = NULL;
    return nuevo_nodo;
}

void slist_agregar_inicio (SList* lista, int dato) {
    SNodo* nuevo_nodo = crear_nodo(dato);
    nuevo_nodo->sig = lista->primero;
    lista->primero = nuevo_nodo;
    if (lista->ultimo == NULL)
        lista->ultimo = nuevo_nodo;
}

void slist_agregar_final (SList* lista, int dato) {
    SNodo* nuevo_nodo = crear_nodo(dato);
    if (lista->ultimo != NULL)
        lista->ultimo->sig = nuevo_nodo;
    lista->ultimo = nuevo_nodo;
    if (lista->primero == NULL) 
        lista->primero = nuevo_nodo;
}


void slist_recorrer_R_feo (SList* lista, FuncionVisitante visit) {
    if (lista->primero != NULL) {
        visit(lista->primero->dato);
        SNodo* temp = lista->primero;
        lista->primero = temp->sig;
        slist_recorrer_R_feo(lista, visit);
        lista->primero = temp;
    }
}

void slist_recorrer_R_aux (SNodo* primer_nodo, FuncionVisitante visit){
    if (primer_nodo != NULL){
        visit(primer_nodo->dato);
        slist_recorrer_R_aux(primer_nodo->sig, visit);
    }
}

void slist_recorrer_R_ok (SList* lista, FuncionVisitante visit) {
    slist_recorrer_R_aux(lista->primero, visit);
}
